$(window).load(function() {
    // CPF
    $("input.cpf").mask("999.999.999-99");
});
